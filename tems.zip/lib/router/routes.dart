const HomePageRoute = "/home";
const AuthPageRoute = "/auth";
const DashboardPageRoute = "/dash";
