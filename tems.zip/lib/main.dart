import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:route_between_two_points/pages/auth/Login.dart';
import 'package:route_between_two_points/pages/home.dart';
import 'package:route_between_two_points/router/routes.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      initialRoute: AuthPageRoute,
      debugShowCheckedModeBanner: false,
      getPages: [
        GetPage(name: HomePageRoute, page: () => HomePage()),
        GetPage(name: AuthPageRoute, page: () => LoginPage()),
      ],
    );
  }
}
