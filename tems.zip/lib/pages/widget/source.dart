import 'package:latlong2/latlong.dart';

class routePoints {
  List<LatLng> routpoints = [
    LatLng(20.729285, 86.880855),
    LatLng(20.05657431306, 86.7570422632)
  ];
}


// CircleMarker(
                    //     point: routpoints[0],
                    //     radius: 100,
                    //     color: Colors.red.withOpacity(0.3), // Circle color
                    //     borderColor: Colors.red,
                    //     borderStrokeWidth: 2),
                    // CircleMarker(
                    //     point: routpoints[0],
                    //     radius: 50,
                    //     color: Colors.red.withOpacity(0.5), // Circle color
                    //     borderColor: Colors.yellow,
                    //     borderStrokeWidth: 2),
                    // CircleMarker(
                    //     point: routpoints[1],
                    //     radius: 100,
                    //     color: Colors.red.withOpacity(0.3), // Circle color
                    //     borderColor: Colors.red,
                    //     borderStrokeWidth: 2),
                    // CircleMarker(
                    //     point: routpoints[1],
                    //     radius: 50,
                    //     color: Colors.red.withOpacity(0.5), // Circle color
                    //     borderColor: Colors.yellow,
                    //     borderStrokeWidth: 2),