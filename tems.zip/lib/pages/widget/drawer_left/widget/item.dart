import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

// ignore: must_be_immutable
class DrawerItem extends StatelessWidget {
  String title;
  Color color;
  SvgPicture ic;
  VoidCallback ontap;

  DrawerItem(
      {super.key,
      required this.title,
      required this.color,
      required this.ic,
      required this.ontap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: ontap,
      child: ListTile(
          title: Text(
            title,
            style: TextStyle(
              color: color,
              fontSize: 18,
            ),
          ),
          leading: ic),
    );
  }
}

// ignore: must_be_immutable
class ExpandItem1 extends StatelessWidget {
  // List<String> title;
  String MainTitle;
  Color color;
  SvgPicture ic;
  ExpandItem1(
      {super.key,
      // required this.title,
      required this.color,
      required this.ic,
      required this.MainTitle});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(10),
      color: Colors.blue,
      child: ExpansionTile(
        childrenPadding: EdgeInsets.zero,
        leading: ic,
        title: Text(
          MainTitle,
          style: const TextStyle(color: Colors.white),
        ),
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(left: 22.0),
            child: ListTile(
              leading:
                  SvgPicture.asset('assets/svg/com.svg', color: Colors.white),
              title: const Text(
                'Communication Center',
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                // Handle submenu 1 tap
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 22.0),
            child: ListTile(
              leading: SvgPicture.asset('assets/svg/s_master.svg',
                  color: Colors.white),
              title: const Text(
                'Station Master',
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                // Handle submenu 2 tap
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 22.0),
            child: ListTile(
              leading: const Icon(Icons.settings_outlined, color: Colors.white),
              title: const Text(
                'Configuration',
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                // Handle submenu 2 tap
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 22.0),
            child: ListTile(
              leading: SvgPicture.asset(
                'assets/svg/data_manage.svg',
                color: Colors.white,
              ),
              title: const Text(
                'Data Management',
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                // Handle submenu 2 tap
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 22.0),
            child: ListTile(
              leading: SvgPicture.asset('assets/svg/spanner.svg',
                  color: Colors.white),
              title: const Text(
                'Meintanance Manager',
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                // Handle submenu 2 tap
              },
            ),
          ),
        ],
      ),
    );
  }
}

class ExpandItem2 extends StatelessWidget {
  // List<String> title;
  String MainTitle;
  Color color;
  SvgPicture ic;
  ExpandItem2(
      {super.key,
      // required this.title,
      required this.color,
      required this.ic,
      required this.MainTitle});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(10),
      color: Colors.blue,
      child: ExpansionTile(
        childrenPadding: EdgeInsets.zero,
        leading: ic,
        title: Text(
          MainTitle,
          style: const TextStyle(color: Colors.white),
        ),
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(left: 22.0),
            child: ListTile(
              leading: SvgPicture.asset('assets/svg/person.svg',
                  color: Colors.white),
              title: const Text(
                'User Management',
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                // Handle submenu 1 tap
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 22.0),
            child: ListTile(
              leading: SvgPicture.asset('assets/svg/notify.svg',
                  color: Colors.white),
              title: const Text(
                'Notification Settings',
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                // Handle submenu 2 tap
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 22.0),
            child: ListTile(
              leading: SvgPicture.asset('assets/svg/user_action_log.svg',
                  color: Colors.white),
              title: const Text(
                'User Action Log',
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                // Handle submenu 2 tap
              },
            ),
          ),
        ],
      ),
    );
  }
}
