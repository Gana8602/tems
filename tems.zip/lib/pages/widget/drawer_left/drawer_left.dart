import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:route_between_two_points/pages/widget/drawer_left/widget/item.dart';

import '../../dashboard/dashboard.dart';

class Drawerleft extends StatelessWidget {
  Drawerleft({Key? key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: Colors.blue,
      child: SafeArea(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            Column(
              children: [
                const Text(
                  'T E M S',
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                Container(
                  height: 80,
                  width: 80,
                  decoration: const BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage('assets/image/admin.png'),
                          fit: BoxFit.cover)),
                ),
                const Text(
                  'Admin',
                  style: TextStyle(
                    color: Colors.white,
                  ),
                ),
                const Text(
                  'ADMINISTRATOR',
                  style: TextStyle(
                    color: Colors.white,
                  ),
                ),
                const Icon(
                  Icons.notifications_outlined,
                  color: Colors.white,
                )
              ],
            ),
            DrawerItem(
              key: UniqueKey(),
              ontap: () {
                Get.toNamed('/home');
              },

              // Get.back();

              title: 'Home',
              color: Colors.white,
              ic: SvgPicture.asset(
                'assets/svg/icons8-home.svg',
                height: 20,
                width: 20,
                color: Colors.white,
              ),
            ),
            DrawerItem(
              ontap: () {
                Navigator.of(context)
                    .push(MaterialPageRoute(builder: (context) => DashBoard()));
              },
              title: 'dashboard',
              color: Colors.white,
              ic: SvgPicture.asset(
                'assets/svg/dash.svg',
                color: Colors.white,
              ),
            ),
            DrawerItem(
              ontap: () {},
              title: 'Reports',
              color: Colors.white,
              ic: SvgPicture.asset(
                'assets/svg/report.svg',
                color: Colors.white,
              ),
            ),
            DrawerItem(
              ontap: () {},
              title: 'Statistics',
              color: Colors.white,
              ic: SvgPicture.asset(
                'assets/svg/stat.svg',
                color: Colors.white,
              ),
            ),
            ExpandItem1(
                color: Colors.white,
                ic: SvgPicture.asset(
                  'assets/svg/s_master_main.svg',
                  color: Colors.white,
                ),
                MainTitle: 'Station Master'),
            ExpandItem2(
                color: Colors.white,
                ic: SvgPicture.asset(
                  'assets/svg/admin_setting.svg',
                  height: 30,
                  width: 30,
                  color: Colors.white,
                ),
                MainTitle: 'Admin Center')
          ],
        ),
      ),
    );
  }
}
