import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';

class MapStyle extends GetxController {
  String mapStyle =
      'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';
  String dark =
      'https://cartodb-basemaps-{s}.global.ssl.fastly.net/dark_all/{z}/{x}/{y}.png';
  String white =
      'https://cartodb-basemaps-{s}.global.ssl.fastly.net/light_all/{z}/{x}/{y}.png';
  String standard =
      'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';
  RxBool isLoading = false.obs;
  Future<void> refreshStyle() async {
    // Simulate some delay with Future.delayed
    await Future.delayed(Duration(seconds: 1));

    // Your refresh logic here
    mapStyle =
        'https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}';
    update(); // Notify listeners that the state has changed
  }

  void changeStyle(String color) {
    isLoading.value = true;
    update();
    if (color == 'white') {
      mapStyle = white;

      // isLoading.value = false;
      update();
    } else if (color == 'dark') {
      mapStyle = dark;
      // isLoading.value = false;
    } else if (color == 'standard') {
      mapStyle = standard;
      // isLoading.value = false;
    }
    Future.delayed(Duration(milliseconds: 100), () {
      update();
      isLoading.value = false;
    });
  }
}
