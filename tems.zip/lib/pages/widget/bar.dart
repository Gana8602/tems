import 'package:flutter/material.dart';

PreferredSize Head(BuildContext context) => PreferredSize(
      preferredSize: Size.fromHeight(kToolbarHeight + 30),
      child: AppBar(
          automaticallyImplyLeading: false,
          iconTheme: const IconThemeData(color: Colors.white),
          backgroundColor: Colors.blue, // Change color as needed
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(30), // Adjust radius as needed
              bottomRight: Radius.circular(30), // Adjust radius as needed
            ),
          ),
          title: const Text(
            'T E M S',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          actions: <Widget>[
            Builder(
              builder: (BuildContext context) {
                return IconButton(
                  icon: const Icon(Icons.menu),
                  onPressed: () {
                    Scaffold.of(context).openDrawer(); // Open the drawer
                  },
                );
              },
            ),
          ]),
    );
