import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:get/get.dart';
import 'package:route_between_two_points/pages/dashboard/dashboard.dart';
import 'package:route_between_two_points/pages/widget/style.dart';
import 'package:route_between_two_points/router/routes.dart';

import 'source.dart';

class MapView extends StatelessWidget {
  const MapView({super.key});

  @override
  Widget build(BuildContext context) {
    final MapStyle controller = Get.put(MapStyle());
    return FlutterMap(
      options: MapOptions(
        center: routePoints().routpoints[0],
        zoom: 10,
      ),
      nonRotatedChildren: [
        AttributionWidget.defaultWidget(
            source: 'OpenStreetMap contributors', onSourceTapped: null),
      ],
      children: [
        TileLayer(
          urlTemplate: controller.mapStyle,
          // 'https://cartodb-basemaps-{s}.global.ssl.fastly.net/dark_all/{z}/{x}/{y}.png',
          subdomains: const ['a', 'b', 'c'],
          userAgentPackageName: 'com.example.app',
        ),
        MarkerLayer(
          markers: [
            Marker(
                point: routePoints().routpoints[0],
                builder: (ctx) => InkWell(
                      onTap: () {
                        print('buoy one tapped');
                      },
                      child: Container(
                        child: const Icon(
                          Icons.power_settings_new,
                          color: Colors.amber,
                        ),
                      ),
                    )),
            Marker(
                point: routePoints().routpoints[1],
                builder: (ctx) => GestureDetector(
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => DashBoard()));
                        print("buoy two tapped");
                      },
                      child: Container(
                        child: const Icon(
                          Icons.power_settings_new,
                          color: Colors.red,
                        ),
                      ),
                    ))
          ],
        ),
        const CircleLayer(
          circles: [],
        ),
      ],
    );
  }
}
