import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:route_between_two_points/pages/widget/bar.dart';
import 'package:route_between_two_points/pages/widget/style.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';

import '../widget/float_Button.dart';
import '../widget/source.dart';

class DashBoard extends StatefulWidget {
  const DashBoard({super.key});

  @override
  State<DashBoard> createState() => _DashBoardState();
}

class _DashBoardState extends State<DashBoard> {
  final MapStyle controller = Get.put(MapStyle());
  final double val = 23.7;
  DateTime? todaydate;
  String? _selectedItem;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    GetDat();
  }

  void GetDat() {
    DateTime now = new DateTime.now();
    DateTime date = new DateTime(now.year, now.month, now.day);
    print('$date, $now');
    setState(() {
      todaydate = now;
    });
  }

  List<String> DataValue = [
    '2881 mS/cm',
    '20.04 PSU',
    '8.11',
    '0%',
    '233.2 NTU',
    '0 mg/L',
    '18.77 ppt',
    '1.11 RFU',
    '202.1 mV',
    '13.8 V'
  ];

  List<dynamic> DataValue2 = [
    {'value': '2881 mS/cm', 'icon': 'assets/svg/test_tube.svg'},
    {'value': '19.8 PSV', 'icon': 'assets/svg/tube2.svg'},
    {'value': '8.11', 'icon': 'assets/svg/ph.svg'},
    {'value': '0%', 'icon': 'assets/svg/o2.svg'},
    {'value': '233.2 NTU', 'icon': 'assets/svg/meter.svg'},
    {'value': '0 mg/L', 'icon': 'assets/svg/o2.svg'},
    {'value': '18.77 ppt', 'icon': 'assets/svg/tube_back.svg'},
    {'value': '1.11 RFU', 'icon': 'assets/svg/leaf.svg'},
    {'value': '202.1 mV', 'icon': 'assets/svg/set.svg'},
    {'value': '13.8 V', 'icon': 'assets/svg/meter_fill.svg'},
  ];
  List<SvgPicture> SvgIconDAta = [
    SvgPicture.asset('assets/svg/test_tube.svg'),
    SvgPicture.asset('assets/svg/tube.svg'),
    SvgPicture.asset(''),
    SvgPicture.asset(''),
    SvgPicture.asset(''),
    SvgPicture.asset(''),
    SvgPicture.asset(''),
    SvgPicture.asset(''),
    SvgPicture.asset(''),
    SvgPicture.asset(''),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: Head(context),
      floatingActionButtonLocation: FloatingActionButtonLocation.endDocked,
      floatingActionButton: const FloatButton(),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(
              'Dashboard',
              style: TextStyle(fontSize: 20),
            ),
            Row(
              children: [
                const Text('Home'),
                const SizedBox(
                  width: 5,
                ),
                Container(
                  height: 15,
                  width: 1,
                  color: Colors.black,
                ),
                const SizedBox(
                  width: 5,
                ),
                const Text('Dashboard'),
              ],
            ),
            Row(
              children: [
                Text(
                  'Last Updated : ',
                  style: TextStyle(color: Colors.blue),
                ),
                Text(
                  ' $todaydate}',
                ),
              ],
            ),
            SizedBox(
              height: 7,
            ),
            const Text(
              'WQ 1',
              style: TextStyle(fontSize: 30, color: Colors.blue),
            ),
            SizedBox(
              height: 7,
            ),
            Row(
              children: [
                DropdownButton<String>(
                  value: _selectedItem,
                  items: <String>['wQ 1', 'Bhitarkanika National Park']
                      .map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  onChanged: (newValue) {
                    setState(() {
                      _selectedItem = newValue;
                    });
                  },
                ),
                const SizedBox(
                  width: 10,
                ),
                Flexible(
                  child: Container(
                    height: 30,
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                        border: Border.all(color: Colors.blue, width: 1)),
                    child: const Center(
                        child: Icon(
                      Icons.add,
                      color: Colors.blue,
                    )),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 20,
            ),
            Container(
              height: 400,
              width: 400,
              decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage('assets/image/noimage.png'),
                      fit: BoxFit.cover)),
            ),
            SizedBox(
              height: 20,
            ),
            Text('Buoy Watch Circle'),
            SizedBox(
              height: 10,
            ),
            Padding(
              padding: EdgeInsets.only(right: 8.0, left: 8.0),
              child: Container(
                  height: 300,
                  width: MediaQuery.of(context).size.width,
                  child: Column(
                    children: [
                      Expanded(
                        child: Stack(
                          alignment: AlignmentDirectional.topStart,
                          children: [
                            FlutterMap(
                              options: MapOptions(
                                center: routePoints().routpoints[0],
                                zoom: 10,
                              ),
                              children: [
                                TileLayer(
                                  urlTemplate: controller.dark,
                                  // 'https://cartodb-basemaps-{s}.global.ssl.fastly.net/dark_all/{z}/{x}/{y}.png',
                                  subdomains: const ['a', 'b', 'c'],
                                  userAgentPackageName: 'com.example.app',
                                ),
                                MarkerLayer(
                                  markers: [
                                    Marker(
                                      point: routePoints().routpoints[0],
                                      builder: ((context) => const Icon(
                                            Icons.location_on,
                                            color: Colors.blueAccent,
                                          )),
                                    )
                                  ],
                                ),
                                CircleLayer(
                                  circles: [
                                    CircleMarker(
                                      point: routePoints().routpoints[0],
                                      radius: 100,
                                      color: Colors.red.withOpacity(0.5),
                                      borderColor: Colors.red,
                                      borderStrokeWidth: 2,
                                    ),
                                    CircleMarker(
                                      point: routePoints().routpoints[0],
                                      radius: 50,
                                      color: Colors.yellow.withOpacity(0.5),
                                      borderColor: Colors.yellow,
                                      borderStrokeWidth: 2,
                                    )
                                  ],
                                )
                              ],
                            ),
                            Positioned(
                              top: 0,
                              left: 0,
                              child: Container(
                                height: 50,
                                width: 50,
                                child: Center(
                                  child: IconButton(
                                    icon: Icon(Icons.fullscreen_rounded),
                                    onPressed: () {},
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  )),
            ),
            SizedBox(
              height: 15,
            ),
            Text('Water'),
            SizedBox(
              height: 15,
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                height: 380,
                width: 380,
                decoration: BoxDecoration(
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.2),
                        offset: Offset(0, 1),
                        blurRadius: 15,
                      )
                    ],
                    borderRadius: BorderRadius.all(Radius.circular(10))),
                child: Column(children: <Widget>[
                  Container(
                      height: 200,
                      width: 200,
                      child: SfRadialGauge(
                          animationDuration: 300,
                          enableLoadingAnimation: true,
                          axes: <RadialAxis>[
                            RadialAxis(
                              minimum: -5,
                              maximum: 45,
                              interval: 50,
                              startAngle: 180,
                              endAngle: 360,
                              pointers: <NeedlePointer>[
                                NeedlePointer(
                                  enableDragging: true,
                                  enableAnimation: true,
                                  animationType: AnimationType.ease,
                                  value: val,
                                )
                              ],
                              ranges: <GaugeRange>[
                                GaugeRange(
                                  startValue: -5,
                                  endValue: val,
                                  color: Colors.amber[300],
                                )
                              ],
                            )
                          ])),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    '23.51',
                    style: TextStyle(fontSize: 22),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    'Water  Temprature',
                    style: TextStyle(fontSize: 27, color: Colors.blue),
                  ),
                ]),
              ),
            ),
            SizedBox(
              height: 15,
            ),
            Column(
              children: [
                for (int i = 0; i < DataValue2.length; i++)
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      height: 380,
                      width: 380,
                      decoration: BoxDecoration(
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.2),
                              offset: Offset(0, 1),
                              blurRadius: 15,
                            )
                          ],
                          borderRadius: BorderRadius.all(Radius.circular(10))),
                      child: Column(children: [
                        Container(
                            height: 200,
                            width: 200,
                            child: Center(
                              child: SvgPicture.asset(
                                '${DataValue2[i]['icon']}',
                                color: Colors.blue,
                                width: 150,
                                height: 150,
                              ),
                            )),
                        SizedBox(
                          height: 5,
                        ),
                        Text(
                          DataValue2[i]['value'].toString(),
                          style: TextStyle(fontSize: 22),
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Text(
                          'Water  Temprature',
                          style: TextStyle(fontSize: 27, color: Colors.blue),
                        ),
                      ]),
                    ),
                  )
              ],
            )
          ]),
        ),
      ),
    );
  }
}
