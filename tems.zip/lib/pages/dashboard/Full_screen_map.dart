import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:get/get.dart';
import 'package:route_between_two_points/pages/widget/style.dart';

import '../widget/source.dart';

class FullView extends StatefulWidget {
  const FullView({super.key});

  @override
  State<FullView> createState() => _FullViewState();
}

class _FullViewState extends State<FullView> {
  final MapStyle controller = Get.put(MapStyle());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('')),
      body: FlutterMap(
        options: MapOptions(
          center: routePoints().routpoints[0],
          zoom: 10,
        ),
        children: [
          TileLayer(
            urlTemplate: controller.dark,
            // 'https://cartodb-basemaps-{s}.global.ssl.fastly.net/dark_all/{z}/{x}/{y}.png',
            subdomains: const ['a', 'b', 'c'],
            userAgentPackageName: 'com.example.app',
          ),
          MarkerLayer(
            markers: [
              Marker(
                  point: routePoints().routpoints[0],
                  builder: ((context) => const Icon(
                        Icons.location_on,
                        color: Colors.blueAccent,
                      )))
            ],
          ),
          CircleLayer(
            circles: [
              CircleMarker(
                  point: routePoints().routpoints[0],
                  radius: 100,
                  color: Colors.red.withOpacity(0.5),
                  borderColor: Colors.red,
                  borderStrokeWidth: 2),
              CircleMarker(
                  point: routePoints().routpoints[0],
                  radius: 50,
                  color: Colors.yellow.withOpacity(0.5),
                  borderColor: Colors.yellow,
                  borderStrokeWidth: 2)
            ],
          )
        ],
      ),
    );
  }
}
