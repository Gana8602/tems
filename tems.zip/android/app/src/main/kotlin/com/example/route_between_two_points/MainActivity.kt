package com.example.route_between_two_points

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
